import { create } from 'zustand';
import {
  apiFetch,
  setStoredToken,
  clearStoredToken,
  getStoredToken,
  onUnauthorized,
} from '@/lib/api-client';

interface AuthState {
  userId: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;

  // Actions
  setAuth: (userId: string | null) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  loginDemo: () => Promise<string | null>;
  logout: () => Promise<void>;
  checkSession: () => Promise<string | null>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  userId: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,

  setAuth: (userId) => {
    set({
      userId,
      isAuthenticated: !!userId,
      isLoading: false,
      error: null,
    });
  },

  setLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error, isLoading: false }),

  loginDemo: async () => {
    set({ isLoading: true, error: null });
    try {
      const res = await apiFetch('/api/auth/demo-login', {
        method: 'POST',
        skipAuthRefresh: true, // Don't trigger 401 handler during login
      });
      if (!res.ok) {
        // Safely parse error — server might be down and Caddy returns HTML
        let errorMsg = 'Login failed';
        try {
          const contentType = res.headers.get('content-type') || '';
          if (contentType.includes('application/json')) {
            const data = await res.json();
            errorMsg = data.error || errorMsg;
          }
        } catch {
          // Ignore JSON parse errors
        }
        throw new Error(errorMsg);
      }
      // Safely parse JSON — server might be down and Caddy returns HTML
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        throw new Error('Server returned an unexpected response. Please try again.');
      }
      const data = await res.json();
      set({
        userId: data.userId,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });

      // Store the session token for Authorization header fallback.
      // In cross-origin sandbox environments, the browser may silently
      // drop the Set-Cookie header, so we must store the token client-side
      // and send it via the Authorization header on subsequent requests.
      if (data.token) {
        setStoredToken(data.token);
      }

      return data.userId;
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Login failed';
      // Don't show "Unexpected token" errors from HTML responses
      if (msg.includes('Unexpected token') || msg.includes('is not valid JSON')) {
        set({
          error: 'Unable to connect to server. Please refresh the page.',
          isLoading: false,
          isAuthenticated: false,
          userId: null,
        });
        return null;
      }
      set({
        error: msg,
        isLoading: false,
        isAuthenticated: false,
        userId: null,
      });
      return null;
    }
  },

  logout: async () => {
    try {
      await apiFetch('/api/auth/logout', {
        method: 'POST',
        skipAuthRefresh: true,
      });
    } catch {
      // Ignore logout errors
    }
    clearStoredToken();
    set({
      userId: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
    });
  },

  checkSession: async () => {
    set({ isLoading: true });
    try {
      const res = await apiFetch('/api/auth/session', {
        skipAuthRefresh: true, // Don't trigger 401 handler during session check
      });
      if (!res.ok) {
        set({ isAuthenticated: false, userId: null, isLoading: false });
        return null;
      }
      // Safely parse JSON — server might be down and Caddy returns HTML
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        set({ isAuthenticated: false, userId: null, isLoading: false });
        return null;
      }
      const data = await res.json();
      if (data.authenticated && data.userId) {
        set({
          userId: data.userId,
          isAuthenticated: true,
          isLoading: false,
        });

        // If the server returned a token in the response, store it
        // for Authorization header fallback
        if (data.token) {
          setStoredToken(data.token);
        }

        return data.userId;
      } else {
        set({
          userId: null,
          isAuthenticated: false,
          isLoading: false,
        });
        return null;
      }
    } catch {
      set({
        userId: null,
        isAuthenticated: false,
        isLoading: false,
      });
      return null;
    }
  },
}));

// Register the global 401 handler
onUnauthorized(() => {
  useAuthStore.getState().setAuth(null);
});
