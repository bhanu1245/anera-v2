import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser, getSessionToken, validateSessionToken } from '@/lib/auth';

// GET /api/auth/session - Check current session status
export async function GET(request: NextRequest) {
  const userId = getCurrentUser(request);

  if (!userId) {
    return NextResponse.json({ authenticated: false });
  }

  // Also return the session token so the client can store it for
  // Authorization header fallback (cross-origin sandbox environments)
  const token = getSessionToken(request);

  return NextResponse.json({
    authenticated: true,
    userId,
    token: token || undefined,
  });
}
