'use client';

import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, User, LogOut, Loader2 } from 'lucide-react';
import { useAuthStore } from '@/stores/auth-store';
import { useProfileStore } from '@/stores/profile-store';
import { useNotificationStore } from '@/stores/notification-store';
import { DiscoverPage } from '@/components/discover/discover-page';
import { ProfileEditor } from '@/components/profile/profile-editor';
import { NotificationBell } from '@/components/notifications/notification-bell';
import { StreakBadge } from '@/components/engagement/streak-badge';
import { ProfileCompletionCard } from '@/components/engagement/profile-completion-card';
import { EngagementPrompts } from '@/components/engagement/engagement-prompts';
import { MatchesPage } from '@/components/matches/matches-page';
import { ChatPage } from '@/components/chat/chat-page';
import { Button } from '@/components/ui/button';

type AppTab = 'discover' | 'matches' | 'profile';

// Type for the other user's profile passed to ChatPage
interface ChatProfile {
  id?: string;
  userId?: string;
  name: string;
  age?: number;
  photos?: { id: string; url: string; order: number; isPrimary: boolean }[];
  bio?: string;
  interests?: string[];
  city?: string;
}

export default function Home() {
  const { userId, isAuthenticated, isLoading, loginDemo, logout, checkSession } = useAuthStore();
  const { fetchProfile } = useProfileStore();
  const { fetchEngagement } = useNotificationStore();
  const [initialized, setInitialized] = useState(false);
  const [activeTab, setActiveTab] = useState<AppTab>('discover');

  // Chat state
  const [chatMatchId, setChatMatchId] = useState<string | null>(null);
  const [chatProfile, setChatProfile] = useState<ChatProfile | null>(null);

  useEffect(() => {
    if (!initialized) {
      checkSession().then((existingUserId) => {
        if (!existingUserId) {
          loginDemo();
        }
        setInitialized(true);
      });
    }
  }, [initialized, checkSession, loginDemo]);

  // Fetch profile and engagement data after auth
  useEffect(() => {
    if (userId && initialized) {
      fetchProfile(userId);
      fetchEngagement();
    }
  }, [userId, initialized, fetchProfile, fetchEngagement]);

  const handleLogout = useCallback(async () => {
    await logout();
    setInitialized(false);
  }, [logout]);

  const handleNavigateFromPrompt = useCallback((tab: string) => {
    setActiveTab(tab as AppTab);
  }, []);

  const handleOpenChat = useCallback((matchId: string, profile: ChatProfile) => {
    setChatMatchId(matchId);
    setChatProfile(profile);
  }, []);

  const handleCloseChat = useCallback(() => {
    setChatMatchId(null);
    setChatProfile(null);
  }, []);

  // Loading state
  if (isLoading || !initialized) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="shrink-0 h-14 flex items-center px-4 border-b border-border/50">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-primary fill-primary" />
            <span className="font-bold text-lg tracking-tight">Anera</span>
          </div>
        </header>
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-4">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
            <p className="text-muted-foreground text-sm">Setting things up...</p>
          </div>
        </main>
      </div>
    );
  }

  // Unauthenticated state
  if (!isAuthenticated || !userId) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="shrink-0 h-14 flex items-center px-4 border-b border-border/50">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-primary fill-primary" />
            <span className="font-bold text-lg tracking-tight">Anera</span>
          </div>
        </header>
        <main className="flex-1 flex items-center justify-center px-4">
          <div className="text-center space-y-6 max-w-sm">
            <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
              <Heart className="w-10 h-10 text-primary" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold">Welcome to Anera</h2>
              <p className="text-muted-foreground text-sm">
                Create your profile and start discovering amazing people
              </p>
            </div>
            <Button onClick={loginDemo} className="gap-2 w-full h-12 rounded-xl font-semibold">
              <Heart className="w-4 h-4" />
              Get Started
            </Button>
          </div>
        </main>
      </div>
    );
  }

  const tabs: { id: AppTab; icon: typeof Heart; label: string }[] = [
    { id: 'discover', icon: Heart, label: 'Discover' },
    { id: 'matches', icon: MessageCircle, label: 'Matches' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header - hide when chat is open */}
      {!chatMatchId && (
      <header className="shrink-0 h-14 flex items-center justify-between px-4 border-b border-border/50 z-40">
        <div className="flex items-center gap-2">
          <Heart className="w-6 h-6 text-primary fill-primary" />
          <span className="font-bold text-lg tracking-tight">Anera</span>
        </div>
        <div className="flex items-center gap-1">
          <StreakBadge compact />
          <NotificationBell />
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="gap-1.5 text-muted-foreground hover:text-destructive h-9"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline text-xs">Logout</span>
          </Button>
        </div>
      </header>
      )}

      {/* Main content */}
      <main className="flex-1 min-h-0 overflow-hidden">
        <AnimatePresence mode="wait">
          {/* Chat view - takes priority over tabs */}
          {chatMatchId && chatProfile ? (
            <motion.div
              key="chat"
              className="h-full"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              <ChatPage
                matchId={chatMatchId}
                otherProfile={chatProfile}
                onBack={handleCloseChat}
              />
            </motion.div>
          ) : activeTab === 'discover' ? (
            <motion.div
              key="discover"
              className="h-full flex flex-col"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {/* Engagement prompts at top */}
              <div className="shrink-0 px-4 pt-3">
                <EngagementPrompts onNavigate={handleNavigateFromPrompt} />
              </div>
              <div className="flex-1 min-h-0">
                <DiscoverPage onOpenChat={handleOpenChat} />
              </div>
            </motion.div>
          ) : activeTab === 'matches' ? (
            <motion.div
              key="matches"
              className="h-full overflow-y-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.2 }}
            >
              <div className="px-4 py-4 space-y-4">
                <ProfileCompletionCard onGoToProfile={() => setActiveTab('profile')} />
                <MatchesPage onOpenChat={handleOpenChat} />
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="profile"
              className="h-full overflow-y-auto"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              <ProfileEditor userId={userId!} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom navigation - hide when chat is open */}
      {!chatMatchId && (
      <nav className="shrink-0 border-t border-border/50 bg-background/95 backdrop-blur-md safe-area-bottom">
        <div className="flex items-center justify-around h-16 max-w-lg mx-auto">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                role="tab"
                className={`flex flex-col items-center justify-center gap-0.5 w-16 h-12 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'text-primary'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
                aria-label={tab.label}
                aria-selected={isActive}
              >
                <div className="relative">
                  <Icon
                    className={`w-5 h-5 transition-all duration-200 ${
                      isActive && tab.id === 'discover' ? 'fill-current' : ''
                    }`}
                  />
                  {isActive && (
                    <motion.div
                      className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary"
                      layoutId="navIndicator"
                      transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    />
                  )}
                </div>
                <span className="text-[10px] font-medium">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
      )}
    </div>
  );
}


