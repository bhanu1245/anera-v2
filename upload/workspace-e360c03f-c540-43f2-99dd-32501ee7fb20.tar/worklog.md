---
Task ID: 1
Agent: Main Agent
Task: Full Frontend Rendering Debug - Blank Screen / Z Logo in Preview Panel

Work Log:
- Inspected full codebase structure (layout.tsx, page.tsx, all stores, all components)
- Started dev server multiple times - discovered server keeps dying within 10-15 seconds
- Tested all API endpoints when server is alive - all return 200 with correct JSON
- Used browser agent to verify rendering on localhost:3000 - renders perfectly, no errors
- Used browser agent to verify rendering via Caddy proxy (port 81) - found critical bug
- Discovered Next.js dev server blocks cross-origin `/_next/*` requests from 127.0.0.1
- Found "Unexpected token '<'" error when API calls receive HTML from Caddy fallback instead of JSON
- Server log showed: "⚠ Blocked cross-origin request from 127.0.0.1 to /_next/* resource"
- Identified that when Next.js server dies, Caddy returns Z logo HTML page
- API calls that receive HTML instead of JSON crash with JSON parse errors

Root Causes Found:
1. Next.js `allowedDevOrigins` missing `127.0.0.1` and `localhost` → blocks JS assets from Caddy proxy
2. All API stores (auth, profile, notification, discover, matches) blindly call `res.json()` without checking content-type
3. When server is down, Caddy returns HTML → `res.json()` throws "Unexpected token '<'" → breaks UI
4. Dev script uses `tee` pipe which can cause SIGPIPE when background process stdout closes

Files Modified:
1. next.config.ts - Added '127.0.0.1' and 'localhost' to allowedDevOrigins
2. package.json - Removed `tee` pipe from dev script
3. src/lib/api-client.ts - Added `safeJsonParse()` utility function
4. src/stores/auth-store.ts - Added content-type checks before JSON parsing in loginDemo/checkSession
5. src/stores/notification-store.ts - Added content-type checks in fetchNotifications/fetchEngagement
6. src/stores/profile-store.ts - Added content-type checks in fetchProfile
7. src/components/discover/discover-page.tsx - Added content-type checks in seedAndFetch
8. src/components/matches/matches-page.tsx - Added content-type checks in fetchMatches

Stage Summary:
- Fixed cross-origin `/_next/*` blocking by adding proxy origins to allowedDevOrigins
- Fixed "Unexpected token" JSON parse errors by checking content-type before parsing
- All API stores now gracefully handle HTML responses from Caddy fallback
- Removed `tee` pipe from dev script to improve server stability
- App renders correctly on both localhost and Caddy proxy when server is running
- Server stability remains an infrastructure concern (server dies after ~10-15 seconds)
